export default function Login() {
  return (
    <main>
      <div>
        <h1>Login</h1>
        <a href="/api/auth/login">Login</a>
      </div>
    </main>
  );
}
