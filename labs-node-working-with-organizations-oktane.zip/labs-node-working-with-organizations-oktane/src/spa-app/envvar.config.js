module.exports = {
  allowed: ["PORT", "AUTH0_DOMAIN", "CLIENT_ID", "API_URL"],
};
